package mehmet;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.Arrays;

@SpringBootApplication
@RestController
public class SpringBootExample {

    public static void main(String[] args) {
        SpringApplication.run(SpringBootExample.class, args);
        System.out.println(String.format("SpringBootExamplen.main(%s)", Arrays.toString(args)));
    }

    @RequestMapping("/")
    public String home() {
        return "Welcome to my Spring Boot application!";
    }
}
