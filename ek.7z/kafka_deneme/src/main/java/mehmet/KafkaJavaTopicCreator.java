package mehmet;

import org.apache.kafka.clients.admin.AdminClient;
import org.apache.kafka.clients.admin.NewTopic;
import org.apache.kafka.clients.admin.CreateTopicsResult;

import java.util.Properties;
import java.util.concurrent.ExecutionException;
import java.util.Arrays;

public class KafkaJavaTopicCreator {
    public static void main(String[] args) throws ExecutionException, InterruptedException {
        String broker = "192.168.1.48:9092";
        createTopics(broker);
    }

    public static void createTopics(String bootstrapServers) {
        Properties properties = new Properties();
        properties.put("bootstrap.servers", bootstrapServers);
        properties.put("connections.max.idle.ms", 10000);
        properties.put("request.timeout.ms", 5000);
        try (AdminClient client = AdminClient.create(properties)) {
            CreateTopicsResult result = client.createTopics(Arrays.asList(
                    new NewTopic("storage-topic", 1, (short) 1),
                    new NewTopic("global-id-topic", 2, (short) 1),
                    new NewTopic("snapshot-topic", 3, (short) 1)));
            try {
                result.all().get();
            } catch (InterruptedException | ExecutionException e) {
                throw new IllegalStateException(e);
            }
        }
    }
}
