package mehmet;

import org.springframework.jdbc.core.JdbcTemplate;
import java.util.List;
import java.util.Map;

public class EmployeeDaoImpl {

    private JdbcTemplate jdbcTemplate;

    public void setJdbcTemplate(JdbcTemplate jdbcTemplate) {
        this.jdbcTemplate = jdbcTemplate;
    }

    public void insertEmployee() {
        String sql = "INSERT INTO employee (name, age) VALUES (?, ?)";
        jdbcTemplate.update(sql, new Object[] { "John Doe", 30 });
        System.out.println("Employee inserted.");
    }

    public void getAllEmployees() {
        String sql = "SELECT * FROM employee";
        List<Map<String, Object>> employees = jdbcTemplate.queryForList(sql);
        for (Map<String, Object> employee : employees) {
            System.out.println("ID: " + employee.get("id"));
            System.out.println("Name: " + employee.get("name"));
            System.out.println("Age: " + employee.get("age"));
        }
    }
}
