const { Kafka } = require('kafkajs');

const topic_name = process.argv[2] || 'Logs2';
const partition = process.argv[3] || 0;

createProducer();

async function createProducer() {
    try {
        //admin işleri
        const kafka = new Kafka({
            clientId: 'kafka_ornek_1',
            brokers: ['192.168.1.32:9092'],
        });

        const producer = kafka.producer();
        console.log("producera bağlanıyor...");
        await producer.connect();
        console.log("producera bağlantı başarılı...");

        const messages_result = await producer.send({
            topic: topic_name,
            messages: [
                {
                    value: 'Bu bir deneme mesajıdır',
                    partition: partition
                }
            ]
        });
        console.log("Gönderim başarılırıdr", JSON.stringify(messages_result));
        await producer.disconnect();
    } catch (error) {
        console.error('hata aldı', error)
    } finally {
        process.exit(0);
    }
}