from contextlib import suppress
from kafka.admin import KafkaAdminClient, NewTopic
from kafka.errors import TopicAlreadyExistsError


# Kafka broker'ına bağlanmak için gerekli olan bilgileri belirtin
BROKERS = '192.168.1.35:9092'

# AdminClient sınıfını kullanarak bir admin client nesnesi oluşturun
admin = KafkaAdminClient(bootstrap_servers=BROKERS,
                         client_id="deneme-kafka")

# Topic oluşturmak için topic_name ve num_partitions ile NewTopic nesnesi oluşturun
new_topic = NewTopic(name='topic_deneme',
                     num_partitions=2, replication_factor=1)

# Oluşturduğunuz topic'i kafka broker'ına eklemek için create_topics metodunu kullanın

with suppress(TopicAlreadyExistsError):
    admin.create_topics(new_topics=[new_topic])
admin.close()
