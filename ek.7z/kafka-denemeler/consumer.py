from kafka import KafkaConsumer

BROKERS = '192.168.1.35:9092'

print("consumer oluşacak")
consumer = KafkaConsumer(bootstrap_servers=BROKERS, client_id="deneme-kafka",
                         group_id='my_favorite_group')

print("consumer bağlanacak")

consumer.subscribe(['topic_deneme'])

print("consumer bağlandı")

for message in consumer:
    print(message)
