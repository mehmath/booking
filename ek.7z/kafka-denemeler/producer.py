import json
from kafka import KafkaProducer


BROKERS = '192.168.1.35:9092'
producer = KafkaProducer(bootstrap_servers=BROKERS, client_id="deneme-kafka",
                         value_serializer=lambda v: json.dumps(v).encode('utf-8'))

# topic'e veri yazmak için send metodunu kullanın
result = producer.send('topic_deneme', value={'key': 'value'}, partition=0)

print(result)

# veri gönderimini tamamlamak için flush metodunu kullanın
producer.flush()
