const { Kafka } = require('kafkajs');

createTopic();

async function createTopic() {
    try {
        //admin işleri
        const kafka = new Kafka({
            clientId: 'kafka_ornek_1',
            brokers: ['192.168.1.32:9092'],
        });

        const admin = kafka.admin();
        console.log("brokera bağlanıyor...");
        await admin.connect();
        console.log("brokera bağlantı başarılı...");
        await admin.createTopics({
            topics: [
                {
                    topic: 'Logs',
                    numpartions: 1
                },
                {
                    topic: 'Logs2',
                    numpartions: 2
                }
            ]
        })
        console.log("Topic oluşturuldu...");
        await admin.disconnect();
    } catch (error) {
        console.error('hata aldı', error)
    } finally {
        process.exit(0);
    }
}